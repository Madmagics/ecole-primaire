-- Fiche Le présent continu (CM2) - anglais, notion 'en_present_continu'. Relancer ce script remplace le contenu de la fiche.
insert into contenu_cours (classe, matiere, titre, contenu, statut, notion_id)
select 'cm2', 'english', 'Le présent continu', $fiche$
[titre]Je suis en train de…[/titre]
[cadre]je suis en train de lire = [b]I'm[/b] read[b][color=#C62828]ing[/color][/b]
je suis en train de manger = [b]I'm[/b] eat[b][color=#C62828]ing[/color][/b][/cadre]
[cadre=astuce]write → writ[b][color=#C62828]ing[/color][/b] (le e disparaît) · swim → swimm[b][color=#C62828]ing[/color][/b] (on double le m).[/cadre]
[page]
[titre]Les mots à connaître[/titre]
[center][font_size=22][b][color=#classe]Des phrases modèles[/color][/b][/font_size][/center]
[table=2][cell bg=#classe border=#classe padding=10,4,10,4][center][color=white][b]français[/b][/color][/center][/cell][cell bg=#classe border=#classe padding=10,4,10,4][center][color=white][b]anglais[/b][/color][/center][/cell][cell bg=#classe_clair border=#classe padding=10,4,10,4][center][font_size=18]je suis en train de jouer[/font_size][/center][/cell][cell bg=#classe_clair border=#classe padding=10,4,10,4][center][font_size=18][b]I'm playing[/b][/font_size][/center][/cell][cell bg=#C6E2F8 border=#42A5F5 padding=10,4,10,4][center][font_size=18]je suis en train de lire[/font_size][/center][/cell][cell bg=#C6E2F8 border=#42A5F5 padding=10,4,10,4][center][font_size=18][b]I'm reading[/b][/font_size][/center][/cell][/table]
[page]
[titre]Je retiens[/titre]
[cadre]I'm + verbe-ing = je suis en train de…[/cadre]
$fiche$, 'publie', n.id from contenu_notions n where n.code = 'en_present_continu'
on conflict (notion_id, classe) where statut <> 'archive'
do update set titre = excluded.titre, contenu = excluded.contenu, matiere = excluded.matiere, statut = 'publie', modifie_le = now()
returning id, classe, titre, statut;
